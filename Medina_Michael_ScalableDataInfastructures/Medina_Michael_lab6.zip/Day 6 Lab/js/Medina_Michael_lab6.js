//alert("JavaScript works!");



//Lab 6 Working With Arrays

//create a fucntion to place array inside of.
function theAvengers() {
    var avengerNames = ["Iron Man", "Black Widow", "Thor", "Hulk"];
    var secretIdentity = ["Tony Stark", "Natasha Romanov", ".... uhhh THOR!?", "Bruce Banner"];

for (var i = 0; i < avengerNames.length; i++) {
    {
        console.log(avengerNames[i] + "'s secret identity is " + secretIdentity[i]);

    }
}
    avengerNames.push("Hawkeye");
    secretIdentity.push("Clint Barton");
    console.log(avengerNames[i]+" 's secret identity is "+ secretIdentity[i]);

}
theAvengers();






